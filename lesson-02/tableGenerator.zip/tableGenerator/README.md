NodeJS-Html-Generator
=====================

NodeJS html email table generator
