
var express = require("express");
var ejs = require("ejs");

var app = express();

app.set("view engine", "ejs");


app.use(express.static("public"));


app.use("*", function(req, res) {
	res.send("hello world");
});


var port = 2000;
app.listen(port, function(){
	console.log("Demo server listening on port " + port);
	var date = new Date();
	console.log("==============");
	console.log("SERVER STARTED at " + date.toISOString());
	console.log("==============");
});
